import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

type Category = 'Todos' | 'Frutas' | 'Bebidas' | 'Naturais';

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: Exclude<Category, 'Todos'>;
  image: string;
  color: string;
  tag?: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  readonly categories: Category[] = ['Todos', 'Frutas', 'Bebidas', 'Naturais'];
  readonly products: Product[] = [
    {
      id: 1, name: 'Mamão Formosa', description: 'Fresco, doce e selecionado',
      price: 12.90, category: 'Frutas', color: 'sun', tag: 'Mais vendido',
      image: 'https://images.unsplash.com/photo-1526318472351-c75fcf070305?auto=format&fit=crop&w=900&q=85',
    },
    {
      id: 2, name: 'Suco Tropical', description: 'Sabor natural em cada gole',
      price: 8.50, category: 'Bebidas', color: 'pink',
      image: 'https://images.unsplash.com/photo-1650292390827-51240d74eb0a?auto=format&fit=crop&w=900&q=85',
    },
    {
      id: 3, name: 'Cesta de Frutas', description: 'Um mix cheio de energia',
      price: 34.90, category: 'Frutas', color: 'peach', tag: 'Favorito',
      image: 'https://images.pexels.com/photos/12597141/pexels-photo-12597141.jpeg?auto=compress&cs=tinysrgb&w=900',
    },
    {
      id: 4, name: 'Mel Natural', description: 'Puro e saboroso',
      price: 22.00, category: 'Naturais', color: 'honey',
      image: 'https://images.pexels.com/photos/7939743/pexels-photo-7939743.jpeg?auto=compress&cs=tinysrgb&w=900',
    },
    {
      id: 5, name: 'Vitamina Especial', description: 'Cremosa e nutritiva',
      price: 14.90, category: 'Bebidas', color: 'mint',
      image: 'https://images.pexels.com/photos/4051764/pexels-photo-4051764.jpeg?auto=compress&cs=tinysrgb&w=900',
    },
    {
      id: 6, name: 'Mix de Castanhas', description: 'Um lanche prático e gostoso',
      price: 19.90, category: 'Naturais', color: 'lavender',
      image: 'https://images.pexels.com/photos/5472169/pexels-photo-5472169.jpeg?auto=compress&cs=tinysrgb&w=900',
    },
  ];

  selectedCategory: Category = 'Todos';
  searchTerm = '';
  isCartOpen = false;
  cart: Record<number, number> = {};
  message = '';
  isEasterEggOpen = false;
  readonly easterEggText = 'MAMÃO É BOM PA CAAAAAAAAAAAARAAAAAAAAAAAAAAAAIO';

  get filteredProducts(): Product[] {
    const query = this.searchTerm.toLocaleLowerCase('pt-BR').trim();
    return this.products.filter((product) =>
      (this.selectedCategory === 'Todos' || product.category === this.selectedCategory) &&
      (!query || `${product.name} ${product.description}`.toLocaleLowerCase('pt-BR').includes(query))
    );
  }

  get cartItems(): { product: Product; quantity: number }[] {
    return this.products
      .filter((product) => (this.cart[product.id] ?? 0) > 0)
      .map((product) => ({ product, quantity: this.cart[product.id] ?? 0 }));
  }

  get cartCount(): number {
    return Object.values(this.cart).reduce((sum, count) => sum + count, 0);
  }

  get cartTotal(): number {
    return this.cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  }

  selectCategory(category: Category): void {
    this.selectedCategory = category;
  }

  search(event: Event): void {
    this.searchTerm = (event.target as HTMLInputElement).value;
  }

  addToCart(product: Product): void {
    this.cart[product.id] = (this.cart[product.id] ?? 0) + 1;
    this.message = `${product.name} adicionado ao carrinho`;
  }

  changeQuantity(productId: number, adjustment: number): void {
    const next = (this.cart[productId] ?? 0) + adjustment;
    if (next <= 0) {
      delete this.cart[productId];
    } else {
      this.cart[productId] = next;
    }
  }

  openEasterEgg(): void {
    this.isEasterEggOpen = true;
  }

  closeEasterEgg(): void {
    this.isEasterEggOpen = false;
  }

  closeMessage(): void {
    this.message = '';
  }

  checkout(): void {
    this.message = 'Loja de demonstração: checkout e pagamento ainda não estão configurados.';
    this.isCartOpen = false;
  }
}
